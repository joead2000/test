package org.example;

public class userDB {
   public boolean changePassword(String username, String password){
       return username.equals("admin");
   }
}
